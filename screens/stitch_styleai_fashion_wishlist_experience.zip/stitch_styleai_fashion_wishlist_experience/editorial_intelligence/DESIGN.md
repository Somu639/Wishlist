---
name: Editorial Intelligence
colors:
  surface: '#f9f9fe'
  surface-dim: '#d9dade'
  surface-bright: '#f9f9fe'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f8'
  surface-container: '#ededf2'
  surface-container-high: '#e8e8ed'
  surface-container-highest: '#e2e2e7'
  on-surface: '#1a1c1f'
  on-surface-variant: '#5b4042'
  inverse-surface: '#2f3034'
  inverse-on-surface: '#f0f0f5'
  outline: '#8f6f72'
  outline-variant: '#e3bdc0'
  surface-tint: '#bd0043'
  primary: '#b90041'
  on-primary: '#ffffff'
  primary-container: '#df2457'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb2ba'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2dfde'
  on-secondary-container: '#636262'
  tertiary: '#5b5c60'
  on-tertiary: '#ffffff'
  tertiary-container: '#747479'
  on-tertiary-container: '#fefcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9dc'
  primary-fixed-dim: '#ffb2ba'
  on-primary-fixed: '#400011'
  on-primary-fixed-variant: '#910031'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#e3e2e7'
  tertiary-fixed-dim: '#c7c6cb'
  on-tertiary-fixed: '#1a1b1f'
  on-tertiary-fixed-variant: '#46464b'
  background: '#f9f9fe'
  on-background: '#1a1c1f'
  surface-variant: '#e2e2e7'
typography:
  display-xl:
    fontFamily: playfairDisplay
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-xl-mobile:
    fontFamily: playfairDisplay
    fontSize: 38px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: playfairDisplay
    fontSize: 36px
    fontWeight: '500'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: playfairDisplay
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
    letterSpacing: 0em
  headline-md:
    fontFamily: playfairDisplay
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: 0em
  headline-sm:
    fontFamily: inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0em
  body-md:
    fontFamily: inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-md:
    fontFamily: inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
  currency-display:
    fontFamily: inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.02em
  score-display:
    fontFamily: playfairDisplay
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
spacing:
  spacing-3xs: 0.125rem
  spacing-2xs: 0.25rem
  spacing-xs: 0.5rem
  spacing-sm: 0.75rem
  spacing-md: 1rem
  spacing-lg: 1.5rem
  spacing-xl: 2rem
  spacing-2xl: 3rem
  spacing-3xl: 4.5rem
  spacing-4xl: 6rem
  gutter-desktop: 1.5rem
  gutter-tablet: 1rem
  gutter-mobile: 0.75rem
  margin-desktop: 3rem
  margin-tablet: 1.5rem
  margin-mobile: 1rem
  touch-target-min: 2.75rem
---

## Brand & Style

This design system defines an authoritative, high-fashion AI decision assistant and luxury e-commerce interface for modern Indian couture and prêt-à-porter. It reconciles the precision of analytical machine intelligence with the tactile, aspirational world of editorial publications like *Vogue India* and contemporary fashion platforms like SSENSE.

### Aesthetic Persona & Ethos
- **Curated Discretion:** The interface never screams. Whitespace acts as structural architecture, framing garments and machine insights with equal gravity.
- **Architectural Tailoring:** Forms are rectilinear, crisp, and disciplined. Soft pills and bubbly skeuomorphism are rejected in favor of sharp, sartorial geometry (0px to subtle 2px micro-radii).
- **Decisive Signal:** Color is reserved strictly for value confirmation, primary conversion paths, and AI confidence telemetry. Garments, textiles, and rich Indian colorways remain the primary visual focal point.

### Emotional Target
The user should feel the quiet confidence of an atelier fitting room paired with the transparent clarity of an executive advisory desk. Interactions feel frictionless, objective, and elevated.

## Colors

The palette relies on a tonal canvas of high-key neutrals, deep ink blacks, and a singular razor-sharp magenta signal.

### Functional Roles
- **Canvas Tones:**
  - `#FFFFFF` (Base Canvas): The primary viewport for product detail pages, high-resolution textile viewports, and primary structural cards.
  - `#FAFAFA` (Offset Layer): Subtle alternation for AI comparison panels, structured metadata trays, and secondary container blocks.
  - `#F5F5F7` (Interactive Base): Architectural dividers, input backgrounds, and disabled states.
- **Typographic Ink:**
  - `#1A1A1A` (Primary Deep Ink): Headlines, numeric metrics, curated recommendations, and high-contrast iconography.
  - `#6E6E73` (Secondary Slate): Attribute labels, technical textile specifications, secondary AI rationales, and timestamps.
- **Accent Signal:**
  - `#FF3F6C` (Fashion Magenta): Reserved exclusively for primary conversion buttons, machine confidence highlights, active style filters, and match scores. It must never be diluted with heavy gradients.
- **Borders & Dividers:**
  - `#E5E5EA` (Tailored Hairline): 1px structural gridlines separating modules without casting heavy shadows.

## Typography

The typographic system pairs the disciplined functionalism of `Inter` with the high-editorial drama of `Playfair Display`.

### Typographic Hierarchy Rules
- **Editorial Voice:** Use `Playfair Display` for collection titles, editorial features, curated style intros, and standalone match indices (`score-display`). It anchors the prestige luxury register.
- **Interface & AI Utility:** Use `Inter` for operational text, attribute breakdowns, technical analysis, controls, and body copy.
- **Labels & System Badges:** Apply uppercase treatment with expanded letter tracking (`0.06em` to `0.08em`) for category anchors, AI verification tags, and textile properties.
- **Currency Presentation:** The Indian Rupee symbol (`₹`) is paired directly with `Inter` tabular figures without extra spacing (e.g., `₹24,500`), preserving clean visual balance and vertical rhythm.

## Layout & Spacing

The layout model is governed by an 8pt architectural rhythm, utilizing crisp vertical registration lines and generous perimeter negative space.

### Structural Grid Architecture
- **Desktop (1200px+):** 12-column fluid grid. Max container width capped at 1440px to ensure editorial photography does not lose density. 48px outer margins with 24px gutters.
- **Tablet (768px - 1199px):** 8-column layout. 24px outer margins with 16px gutters. AI analysis splits into side-by-side or stacked summary drawers.
- **Mobile (320px - 767px):** 4-column layout. 16px outer margins with 12px gutters.

### Editorial Density & Negative Space
- Maintain generous macro-whitespace (`spacing-3xl` and `spacing-4xl`) between major sections to let garment imagery breathe.
- Micro-whitespace within analytical cards (`spacing-xs` to `spacing-md`) remains compact and dense to reflect structured diagnostic efficiency.
- All interactive controls respect the hard 44px (`touch-target-min`) bounding box to ensure effortless touch interaction on mobile devices.

## Elevation & Depth

This system avoids blurred drop shadows, multi-tiered z-plane elevation, and skeuomorphic casting. Depth is communicated strictly through surface layering and hairline borders.

### Surface Tiers & Hairline Delimitation
- **Level 0 (Canvas):** `#FFFFFF` pure backdrop.
- **Level 1 (Panels & Intelligence Cards):** `#FAFAFA` with a solid 1px border rendered in `#E5E5EA`.
- **Level 2 (Drawers & Sticky Action Bars):** Elevated via a solid 1px hairline border in `#E5E5EA` on top or sides, backed by a pure white fill. Optional micro ambient diffusion: `0 8px 24px rgba(0, 0, 0, 0.04)` strictly when overlapping full-bleed photography.
- **Level 3 (Modals & Full Overlays):** Grounded by an opaque 40% `#1A1A1A` backdrop, framing a sharp, bordered white dialog box.

## Shapes

The geometric signature is completely rectilinear (`roundedness: 0`). 

### Tailored Edge Language
- Buttons, input controls, AI score containers, image frames, and floating trays must retain razor-sharp corners (0px border-radius).
- Pills and rounded corners are strictly prohibited; they conflict with the bespoke Indian luxury tailoring identity and high-fashion editorial discipline.
- Visual rhythm is created through proportional aspect ratios (3:4 portrait ratios for garment imagery, 1:1 for detail crops, and 16:9 for AI comparison side-by-sides) rather than contour smoothing.

## Components

### Buttons
- **Primary Action:** Solid `#1A1A1A` background with `#FFFFFF` text. Sharp 0px corners, 48px height, 24px horizontal padding. Letter-spaced 12px uppercase label. Active hover state switches to `#FF3F6C`.
- **AI Recommendation Action:** Solid `#FF3F6C` background with `#FFFFFF` text. Used exclusively for "Generate Outfit Match", "Run Fit Diagnostic", or primary purchase triggers.
- **Secondary / Outline:** Transparent background, 1px `#1A1A1A` border, `#1A1A1A` text. On hover, background shifts to `#FAFAFA`.
- **Ghost / Editorial:** No border, text in `#1A1A1A` with an underlined hairline indicator resting 4px below baseline.

### Chips & Badges
- **Editorial Chips:** Sharp 0px borders, 1px `#E5E5EA` perimeter, `#FAFAFA` fill, 32px height. Text rendered in `label-md` using `#1A1A1A`.
- **AI Diagnostic Badges:** Hairline `#FF3F6C` border, light `#FF3F6C` tint or `#FFFFFF` fill with `#FF3F6C` typography. Used for fit match indicators (e.g., "98% OCCASION MATCH").

### Form Fields & Selection
- **Text Inputs:** 48px height, 0px radius, `#FAFAFA` fill, 1px `#E5E5EA` bottom border or full rectangular stroke. Floating micro-labels in `#6E6E73`. Focus state switches the border to `#1A1A1A` with zero glow.
- **Checkboxes & Radios:** Precision 18px squares with sharp corners. Unselected: 1px `#E5E5EA` border. Selected: Solid `#1A1A1A` fill with a white hairline mark or inner dot.

### Cards & Intelligence Panels
- **Garment Card:** Minimalist, borderless 3:4 portrait image frame. Image resting on `#F5F5F7`. Bottom meta area features brand in `label-md` (`#6E6E73`), silhouette name in `body-md` (`#1A1A1A`), and localized price formatted as `currency-display`.
- **AI Comparison Drawer:** Surface `#FAFAFA` framed with a 1px `#E5E5EA` border. Split-column layout contrasting garment metrics: drape score, climate compatibility, event alignment, and fabric integrity.

### Currency Display
- The Indian Rupee (`₹`) symbol must always match the font size and baseline of the accompanying numerical figure, set in `Inter` semi-bold with consistent tabular alignment across product grids and bag summaries.